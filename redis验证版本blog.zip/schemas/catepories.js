//引入mongoose模块
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


//创建用户表结构
module.exports = new Schema({
   //分类名
   name:String
   
});